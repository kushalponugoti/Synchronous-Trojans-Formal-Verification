import glob
import os

list_of_files = glob.glob('*.smt2')
F2 = open("final.txt","w+")
for file_name in list_of_files:
    F1 = open(file_name,'r')
    print (file_name)
    command = "cmd.exe /c z3 " + file_name + " -st > output.txt"
    os.system(command)
    F1.close()
    F3 = open("output.txt","r")
    firstline = F3.readline()
    F3.close()
    with open("output.txt","r") as F3:
        F2.writelines(file_name)
        F2.writelines("\n")
        F2.writelines(firstline)
        for line in F3:
            pass
        lastline = line
        F2.writelines(lastline)
        F2.writelines("\n\n")
F2.close()
        

            
            
            
    
    
