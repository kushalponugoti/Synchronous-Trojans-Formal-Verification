import os
#this module for shift register (flip-flops)
L = ["te2","te1","t0","te0"]
M = ["te2","te1","t1","te0"]
pivot = 2 #position of t0. starts from 0
for x in range(1,4): #1,2,3,4,5,6,7
    filename = "trojanmac482424trojan" + str(x) + ".smt2"
    with open("trojanmac482424trojan0.smt2", "r") as myfile: #original file
        head = [next(myfile) for x in range(2729)] #parse thru the first 164 lines
    f1 = open(filename,"w") #new smt file gets created here
    f1.writelines(head)
    text1 = ["					(trojan0 (concat "]
    f1.writelines(text1)
    f1.writelines(["%s " %item for item in L]) #paste L
    f1.writelines("))\n")
    text2 = ["					(trojan1 (concat "]
    f1.writelines(text2)
    f1.writelines(["%s " %item for item in M]) #paste M
    f1.writelines("))\n")
    with open("trojanmac482424trojan0.smt2","r") as f:
        for i in range(2731): #paste left over lines
            f.readline()
        for line in f:
            f1.writelines(line)
    f1.close()
    print (filename)
    temp1 = L[pivot]
    L[pivot] = L[pivot-1]
    L[pivot-1] = temp1
    temp1 = M[pivot]
    M[pivot] = M[pivot-1]
    M[pivot-1] = temp1
    pivot = pivot-1

#this module for inputs Xmul
J = ["xe22","xe21","xe20","xe19","xe18","xe17","xe16","xe15","xe14","xe13","xe12","xe11","xe10","xe9","xe8","xe7","xe6","xe5","xe4","xe3","xe2","xe1","am0","xe0"]
K = ["xe22","xe21","xe20","xe19","xe18","xe17","xe16","xe15","xe14","xe13","xe12","xe11","xe10","xe9","xe8","xe7","xe6","xe5","xe4","xe3","xe2","xe1","am1","xe0"]
pivot = 22
for x in range(1,24): #1,2,3
    filename = "trojanmac482424inputx" + str(x) + ".smt2"
    with open("trojanmac482424inputx0.smt2", "r") as myfile:
        head = [next(myfile) for x in range(2750)]
    f1 = open(filename,"w")
    f1.writelines(head)
    text1 = ["					(Xmul1 (concat "]
    f1.writelines(text1)
    f1.writelines(["%s " %item for item in J]) #paste L
    f1.writelines("))\n")
    text2 = ["					(Xmul2 (concat "]
    f1.writelines(text2)
    f1.writelines(["%s " %item for item in K]) #paste M
    f1.writelines("))\n")
    with open("trojanmac482424inputx0.smt2", "r") as f:
        for i in range(2752):
            f.readline()
        for line in f:
            f1.writelines(line)
    f1.close()
    print (filename)
    temp1 = J[pivot]
    J[pivot] = J[pivot-1]
    J[pivot-1] = temp1
    temp1 = K[pivot]
    K[pivot] = K[pivot-1]
    K[pivot-1] = temp1
    pivot = pivot-1

#this module for inputs Ymul
J = ["ye22","ye21","ye20","ye19","ye18","ye17","ye16","ye15","ye14","ye13","ye12","ye11","ye10","ye9","ye8","ye7","ye6","ye5","ye4","ye3","ye2","ye1","am0","ye0"]
K = ["ye22","ye21","ye20","ye19","ye18","ye17","ye16","ye15","ye14","ye13","ye12","ye11","ye10","ye9","ye8","ye7","ye6","ye5","ye4","ye3","ye2","ye1","am1","ye0"]
pivot = 22
for x in range(1,24): #1,2,3
    filename = "trojanmac482424inputy" + str(x) + ".smt2"
    with open("trojanmac482424inputy0.smt2", "r") as myfile:
        head = [next(myfile) for x in range(2750)]
    f1 = open(filename,"w")
    f1.writelines(head)
    text1 = ["					(Ymul1 (concat "]
    f1.writelines(text1)
    f1.writelines(["%s " %item for item in J]) #paste L
    f1.writelines("))\n")
    text2 = ["					(Ymul2 (concat "]
    f1.writelines(text2)
    f1.writelines(["%s " %item for item in K]) #paste M
    f1.writelines("))\n")
    with open("trojanmac482424inputy0.smt2", "r") as f:
        for i in range(2752):
            f.readline()
        for line in f:
            f1.writelines(line)
    f1.close()
    print (filename)
    temp1 = J[pivot]
    J[pivot] = J[pivot-1]
    J[pivot-1] = temp1
    temp1 = K[pivot]
    K[pivot] = K[pivot-1]
    K[pivot-1] = temp1
    pivot = pivot-1

#this module for accumulator flip flops
P = ["acc46","acc45","acc44","acc43","acc42","acc41","acc40","acc39","acc38","acc37","acc36","acc35","acc34","acc33","acc32","acc31","acc30","acc29","acc28","acc27","acc26","acc25","acc24","acc23","acc22","acc21","acc20","acc19","acc18","acc17","acc16","acc15","acc14","acc13","acc12","acc11","acc10","acc9","acc8","acc7","acc6","acc5","acc4","acc3","acc2","acc1","am0","acc0"]
Q = ["acc46","acc45","acc44","acc43","acc42","acc41","acc40","acc39","acc38","acc37","acc36","acc35","acc34","acc33","acc32","acc31","acc30","acc29","acc28","acc27","acc26","acc25","acc24","acc23","acc22","acc21","acc20","acc19","acc18","acc17","acc16","acc15","acc14","acc13","acc12","acc11","acc10","acc9","acc8","acc7","acc6","acc5","acc4","acc3","acc2","acc1","am1","acc0"]
pivot = 46
for x in range(1,48):
    filename = "trojanmac482424acc" + str(x) + ".smt2"
    with open("trojanmac482424acc0.smt2", "r") as myfile:
        head = [next(myfile) for x in range(2774)]
    f1 = open(filename,"w")
    f1.writelines(head)
    text1 = ["					(accnew1 (concat "]
    f1.writelines(text1)
    f1.writelines(["%s " %item for item in P]) #paste P
    f1.writelines("))\n")
    text2 = ["					(accnew2 (concat "]
    f1.writelines(text2)
    f1.writelines(["%s " %item for item in Q]) #paste Q
    f1.writelines("))\n")
    with open("trojanmac482424acc0.smt2", "r") as f:
        for i in range(2776):
            f.readline()
        for line in f:
            f1.writelines(line)
    f1.close()
    print(filename)
    temp1 = P[pivot]
    P[pivot] = P[pivot-1]
    P[pivot-1] = temp1
    temp1 = Q[pivot]
    Q[pivot] = Q[pivot-1]
    Q[pivot-1] = temp1
    pivot = pivot-1
