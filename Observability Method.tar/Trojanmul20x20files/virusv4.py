import glob, os, threading
from queue import Queue, Empty
import time

def worker_func():
	while not stopped.is_set():
		try:
			com = q.get_nowait()
		except Empty:
			continue
		try:
			os.system(com)
		except Exception as e:
			print ("[-] Error running command %s", (str(e)))
		finally:
			q.task_done()

commands = []
t0 = time.time()
list_of_files = glob.glob('*.smt2')
for file_name in list_of_files:
	#F1 = open(file_name,'r')
	file_noext = os.path.splitext(file_name)[0]
	command = "cmd.exe /c z3 " + file_name + " -st > " + file_noext + ".txt"
	commands.append(command)
	#os.system(command)
thread_count = 44
stopped = threading.Event()
q = Queue()
print ("-- Processing %s tasks in thread queue with %s thread limit",(str(len(commands)), str(thread_count)))
for item in commands:
	q.put(item)
for i in range(thread_count):
	t = threading.Thread(target = worker_func)
	t.start()
q.join()
stopped.set()

F1 = open("final parallel.txt","w+")
file_list = glob.glob('*.txt')
for textlist in file_list:
	line = []
	F2 = open(textlist,"r")
	firstline = F2.readline()
	F1.writelines(textlist)
	F1.writelines("\n")
	F1.writelines(firstline)
	F2.close()
	for line in open(textlist):
		pass
	lastline = line
	F1.writelines(lastline)
	F1.writelines("\n\n")
	F2.close()
t1 = time.time()
total = t1 - t0
tt = "Total time = " + str(total) + "seconds"
F1.writelines(tt)
F1.close()

	


    
        

            
            
            
    
    
